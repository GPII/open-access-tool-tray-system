var MAIN_IP = "oatts.local";   //---###
 //---### var MAIN_IP = "oatts.trace.wisc.edu";

var PROTOCOL = "http://";   //---###
//---### var PROTOCOL = "https://";

var MAIN_PATH = PROTOCOL + MAIN_IP + "/oatts/";
var MAIN_URL = MAIN_PATH + "login.php";
var LOGOUT_URL = MAIN_PATH + "includes/process_logout.php";
