<?php

?>

var globalID = "";
var widgetExtrnData = "";
var loadedWidgetName = "";
var myHash="";
var myFolder="";
var myName="";
var iframe = true;

<?php
/*
	if (isset($_GET['path']) && isset($_GET['name'])) {

		if (isset($_GET['hash'])) {
			echo "\nmyHash = \"".$_GET['hash']."\";";
		}
		echo "\nmyFolder = \"".$_GET['path']."\";";
		echo "\nmyName = \"".$_GET['name']."\";";
		echo "\niframe = false;\n";
	
	}
*/
?>


