<?Header('content-type: application/x-javascript'); ?>

new traySystem.window(
{ 
	title:'Tool Chooser',
	url: '#',
	width:600,
	height:220,
	content: '<div style="height:95%;padding:10px"><iframe src="#" width="100%" height="100%" style="z-index:1"></iframe></div>'
});

