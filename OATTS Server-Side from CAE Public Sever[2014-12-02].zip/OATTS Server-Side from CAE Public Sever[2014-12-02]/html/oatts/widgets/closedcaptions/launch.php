<?Header('content-type: application/x-javascript'); ?>

new traySystem.window(
{ 
	title:'Closed Captions',
	width:1020,
	height:680,
	content: '<div style="height:95%;padding:10px"><iframe src="http://192.168.23.241/CC/CapChoose4.html" width="100%" height="100%" style="z-index:1"></iframe></div>'
});

