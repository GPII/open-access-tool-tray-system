// Need to change the line below to be your widget alias (the folder it resides in)
// This is case sensitive and must be correct for the widget to work both "in site" and "out of site" (popup).


new traySystem.window(
{ 
	title:'Closed Captions',
	width:1020,
	height:680,
	content: '<div style="height:95%;padding:10px"><iframe src="http://174.122.236.154:8080/login.htm" width="100%" height="100%" style="z-index:1"></iframe></div>'
});

