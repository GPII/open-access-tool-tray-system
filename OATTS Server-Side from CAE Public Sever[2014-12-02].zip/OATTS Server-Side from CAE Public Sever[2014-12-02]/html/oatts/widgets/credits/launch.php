<?Header('content-type: application/x-javascript'); ?>

new traySystem.window(
{ 
	title:'Assistance On Demand Providers',
	width:320,
	height:220,
	content: '<div style="height:95%;padding:10px"><iframe src="http://192.168.23.241/CaptionChooser/CapChoose4.html" width="100%" height="100%" style="z-index:1"></iframe></div>'
});

