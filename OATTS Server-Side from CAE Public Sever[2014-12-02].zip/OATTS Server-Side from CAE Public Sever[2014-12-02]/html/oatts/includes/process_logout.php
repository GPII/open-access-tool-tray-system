<?php
include 'path.php';
include ROOT_PATH . '/process_logout.php';

