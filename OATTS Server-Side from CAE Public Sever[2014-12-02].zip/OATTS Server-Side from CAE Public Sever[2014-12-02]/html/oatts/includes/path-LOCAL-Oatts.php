<?php
	defined('ROOT_PATH') or define('ROOT_PATH','/var/www/oattsincludes');
	