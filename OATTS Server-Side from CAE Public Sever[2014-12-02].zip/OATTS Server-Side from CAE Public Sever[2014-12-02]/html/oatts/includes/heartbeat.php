<?php
include 'path.php';
include ROOT_PATH . '/heartbeat.php';

